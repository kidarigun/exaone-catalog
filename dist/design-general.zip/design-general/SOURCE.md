# 출처

이 Skill은 nextlevelbuilder/ui-ux-pro-max-skill 저장소의 `.claude/skills/design`를 그대로 옮긴 것입니다.

- 원본: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/tree/2de1134dc4d1cfe112934611ae5803ae17a1bd7e/.claude/skills/design
- 라이선스: MIT (LICENSE)
- 내용은 바꾸지 않았습니다.
