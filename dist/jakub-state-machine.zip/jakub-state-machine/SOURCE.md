# 출처

이 Skill은 jakubkrehel/skills 저장소의 `skills/state-machine`를 그대로 옮긴 것입니다.

- 원본: https://github.com/jakubkrehel/skills/tree/547d415dc10a23e66088eba5aa6664e6e772432c/skills/state-machine
- 라이선스: MIT (LICENSE)
- 내용은 바꾸지 않았습니다.
