# 출처

이 Skill은 anthropics/skills 저장소의 `skills/brand-guidelines`를 그대로 옮긴 것입니다.

- 원본: https://github.com/anthropics/skills/tree/1780c5e5a552fd4d1c9d6a7b0cab26b0c2bef064/skills/brand-guidelines
- 라이선스: Apache-2.0 (LICENSE.txt)
- 내용은 바꾸지 않았습니다.
