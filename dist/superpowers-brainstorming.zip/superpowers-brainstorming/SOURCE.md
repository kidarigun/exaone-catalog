# 출처

이 Skill은 obra/superpowers 저장소의 `skills/brainstorming`를 그대로 옮긴 것입니다.

- 원본: https://github.com/obra/superpowers/tree/22f0b463e7a5e579904dd6211a520321035526f7/skills/brainstorming
- 라이선스: MIT (LICENSE)
- 내용은 바꾸지 않았습니다.
