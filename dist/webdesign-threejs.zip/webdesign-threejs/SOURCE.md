# 출처

이 Skill은 MengTo/Skills 저장소의 `agent-skills/web-design/threejs`를 그대로 옮긴 것입니다.

- 원본: https://github.com/MengTo/Skills/tree/1a32b45a57f435f1564544e7267a71fc3b180a7a/agent-skills/web-design/threejs
- 라이선스: MIT (LICENSE)
- 내용은 바꾸지 않았습니다.
